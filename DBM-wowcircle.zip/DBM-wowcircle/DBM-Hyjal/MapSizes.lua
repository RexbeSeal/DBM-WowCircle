DBM:RegisterMapSize("ClassicMountHyjal", 0, 2500, 1666.666)
DBM:RegisterMapSize("CoTMountHyjal", 0, 2500, 1666.666)