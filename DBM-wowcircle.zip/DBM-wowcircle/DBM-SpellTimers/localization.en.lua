DBM_SpellsUsed_Translations = {}

local L = DBM_SpellsUsed_Translations



L.TabCategory_SpellsUsed	= "Spell/Skill Cooldowns"
L.AreaGeneral 			= "General Settings for Spell and Skill Cooldowns"
L.Enable 			= "Enable cooldown timers"
L.Show_LocalMessage 		= "Show local message on cast"
L.Enable_inRaid			= "Show cooldowns only from raid members"
L.Enable_inBattleground		= "Show cooldowns also in battlegrounds"
L.Enable_Portals		= "Show portal durations"
L.Reset				= "Reset to defaults"
L.Local_CastMessage 		= "Detected cast: %s"
L.AreaAuras 			= "Setup spells/skills"
L.SpellID 			= "Spell ID"
L.BarText 			= "Bar Text (default: %spell: %player)"
L.Cooldown 			= "Cooldown"
L.Error_FillUp			= "Please fill all fields before adding a new one"




