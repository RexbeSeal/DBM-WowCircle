DBM:RegisterMapSize("SunwellPlateau", 0, 995.6, 664.2)
DBM:RegisterMapSize("SunwellPlateau", 1, 465.0, 310.0)