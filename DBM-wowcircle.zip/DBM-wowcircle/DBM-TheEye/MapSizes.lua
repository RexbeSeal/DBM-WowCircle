DBM:RegisterMapSize("TempestKeep", 0, 1575, 1050)
DBM:RegisterMapSize("TempestKeep", 1, 1575, 1050)