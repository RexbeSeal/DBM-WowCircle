DBM:RegisterMapSize("TheNexus", 1, 1101.280975342, 734.1874999997) -- The Nexus
