DBM:RegisterMapSize("VioletHold", 1, 256.229003907, 170.82006836) -- The Violet Hold
